de.httc.plugin.user.selfRegistrationEnabled = false
