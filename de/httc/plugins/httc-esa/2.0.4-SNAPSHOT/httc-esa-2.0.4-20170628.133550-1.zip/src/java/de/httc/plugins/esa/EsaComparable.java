package de.httc.plugins.esa;

import edu.kit.aifb.concept.IConceptVector;

public interface EsaComparable {
	IConceptVector getEsaVector();
}
