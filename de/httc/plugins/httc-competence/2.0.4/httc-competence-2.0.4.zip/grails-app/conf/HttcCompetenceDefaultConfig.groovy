grails {
    plugin {
        competence {
        }
    }
}
