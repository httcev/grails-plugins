package de.httc.plugins.common

class AuthService {
	def canAttach(domain, user = null) {
		return true
	}

	def canEdit(domain, user = null) {
		return true
	}

	def canDelete(domain, user = null) {
		return true
	}
}
